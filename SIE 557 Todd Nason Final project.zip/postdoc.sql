/*
-- Query: SELECT * FROM 557_final_project.postdoc
LIMIT 0, 1000

-- Date: 2022-05-06 09:11
*/
INSERT INTO `` (`Phd_ID`,`Phd_Fname`,`Phd_Lname`) VALUES (1,'Purva','Vats');
INSERT INTO `` (`Phd_ID`,`Phd_Fname`,`Phd_Lname`) VALUES (2,'Brittany','Angarola');
INSERT INTO `` (`Phd_ID`,`Phd_Fname`,`Phd_Lname`) VALUES (3,'Mattia','Brugiolo');
INSERT INTO `` (`Phd_ID`,`Phd_Fname`,`Phd_Lname`) VALUES (5,'Aditya','Iyer');
INSERT INTO `` (`Phd_ID`,`Phd_Fname`,`Phd_Lname`) VALUES (6,'Peter','Audano III');
INSERT INTO `` (`Phd_ID`,`Phd_Fname`,`Phd_Lname`) VALUES (7,'Parithi','Balachandran');
INSERT INTO `` (`Phd_ID`,`Phd_Fname`,`Phd_Lname`) VALUES (8,'Ardian','Ferraj');
INSERT INTO `` (`Phd_ID`,`Phd_Fname`,`Phd_Lname`) VALUES (9,'Kourtney','Graham');
INSERT INTO `` (`Phd_ID`,`Phd_Fname`,`Phd_Lname`) VALUES (10,'Ruby','Boateng');
INSERT INTO `` (`Phd_ID`,`Phd_Fname`,`Phd_Lname`) VALUES (13,'Timothy','Hines');
INSERT INTO `` (`Phd_ID`,`Phd_Fname`,`Phd_Lname`) VALUES (15,'Ann','Wells');
INSERT INTO `` (`Phd_ID`,`Phd_Fname`,`Phd_Lname`) VALUES (16,'Minji','Kim');
INSERT INTO `` (`Phd_ID`,`Phd_Fname`,`Phd_Lname`) VALUES (17,'Ali','Pour');
INSERT INTO `` (`Phd_ID`,`Phd_Fname`,`Phd_Lname`) VALUES (19,'Raman','Lawal');
INSERT INTO `` (`Phd_ID`,`Phd_Fname`,`Phd_Lname`) VALUES (20,'Lydia','Woolridge');
INSERT INTO `` (`Phd_ID`,`Phd_Fname`,`Phd_Lname`) VALUES (21,'Alaina','Reagan');
INSERT INTO `` (`Phd_ID`,`Phd_Fname`,`Phd_Lname`) VALUES (22,'Niran','Hadad');
INSERT INTO `` (`Phd_ID`,`Phd_Fname`,`Phd_Lname`) VALUES (23,'Surjeet','Singh');
INSERT INTO `` (`Phd_ID`,`Phd_Fname`,`Phd_Lname`) VALUES (25,'Francis','O\'Neill');
INSERT INTO `` (`Phd_ID`,`Phd_Fname`,`Phd_Lname`) VALUES (26,'Aaron','Taylor');
INSERT INTO `` (`Phd_ID`,`Phd_Fname`,`Phd_Lname`) VALUES (27,'Kwondo','Kim');
INSERT INTO `` (`Phd_ID`,`Phd_Fname`,`Phd_Lname`) VALUES (28,'Feyza','Yilmaz');
INSERT INTO `` (`Phd_ID`,`Phd_Fname`,`Phd_Lname`) VALUES (29,'Abhishek','Agarwal');
INSERT INTO `` (`Phd_ID`,`Phd_Fname`,`Phd_Lname`) VALUES (30,'Shilpita','Karmakar');
INSERT INTO `` (`Phd_ID`,`Phd_Fname`,`Phd_Lname`) VALUES (31,'Yang','Liu');
INSERT INTO `` (`Phd_ID`,`Phd_Fname`,`Phd_Lname`) VALUES (33,'Selcan','Aydin');
INSERT INTO `` (`Phd_ID`,`Phd_Fname`,`Phd_Lname`) VALUES (34,'Holly','Beaulac');
INSERT INTO `` (`Phd_ID`,`Phd_Fname`,`Phd_Lname`) VALUES (35,'Eric','Bogenshchultz');
INSERT INTO `` (`Phd_ID`,`Phd_Fname`,`Phd_Lname`) VALUES (36,'Navdeep','Gogna');
INSERT INTO `` (`Phd_ID`,`Phd_Fname`,`Phd_Lname`) VALUES (37,'Austin','Korgan');
INSERT INTO `` (`Phd_ID`,`Phd_Fname`,`Phd_Lname`) VALUES (38,'Diana','Cadena-Castaneda');
INSERT INTO `` (`Phd_ID`,`Phd_Fname`,`Phd_Lname`) VALUES (39,'Daniel','Cortes-Perez');
INSERT INTO `` (`Phd_ID`,`Phd_Fname`,`Phd_Lname`) VALUES (40,'Emily','Swanzey');
INSERT INTO `` (`Phd_ID`,`Phd_Fname`,`Phd_Lname`) VALUES (41,'Minghao','Gong');
INSERT INTO `` (`Phd_ID`,`Phd_Fname`,`Phd_Lname`) VALUES (42,'Anil','Akturk');
INSERT INTO `` (`Phd_ID`,`Phd_Fname`,`Phd_Lname`) VALUES (43,'Amandine','Jarysta');
INSERT INTO `` (`Phd_ID`,`Phd_Fname`,`Phd_Lname`) VALUES (44,'Rodrigo','Castro');
INSERT INTO `` (`Phd_ID`,`Phd_Fname`,`Phd_Lname`) VALUES (45,'Kousuke','Mouri');
INSERT INTO `` (`Phd_ID`,`Phd_Fname`,`Phd_Lname`) VALUES (46,'Jayna','Mistry');
INSERT INTO `` (`Phd_ID`,`Phd_Fname`,`Phd_Lname`) VALUES (47,'Jennifer','SanMiguel');
INSERT INTO `` (`Phd_ID`,`Phd_Fname`,`Phd_Lname`) VALUES (48,'Asa','Thibodeau');
INSERT INTO `` (`Phd_ID`,`Phd_Fname`,`Phd_Lname`) VALUES (49,'Samir','Amin');
INSERT INTO `` (`Phd_ID`,`Phd_Fname`,`Phd_Lname`) VALUES (50,'Kevin','Anderson');
INSERT INTO `` (`Phd_ID`,`Phd_Fname`,`Phd_Lname`) VALUES (51,'Frederick','Varn');
INSERT INTO `` (`Phd_ID`,`Phd_Fname`,`Phd_Lname`) VALUES (52,'Eunhee','Yi');
