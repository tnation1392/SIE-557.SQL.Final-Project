/*
-- Query: SELECT * FROM 557_final_project.research
LIMIT 0, 1000

-- Date: 2022-05-06 09:15
*/
INSERT INTO `` (`Research_ID`,`Research_Field`) VALUES (1,'Microbiome');
INSERT INTO `` (`Research_ID`,`Research_Field`) VALUES (2,'Cancer');
INSERT INTO `` (`Research_ID`,`Research_Field`) VALUES (5,'Structural and Regulatory Genomics');
INSERT INTO `` (`Research_ID`,`Research_Field`) VALUES (7,'Gene Ontology');
INSERT INTO `` (`Research_ID`,`Research_Field`) VALUES (8,'Neuroscience');
INSERT INTO `` (`Research_ID`,`Research_Field`) VALUES (9,'Fertility');
INSERT INTO `` (`Research_ID`,`Research_Field`) VALUES (10,'Computational Biology');
INSERT INTO `` (`Research_ID`,`Research_Field`) VALUES (11,'Bioinformatics');
INSERT INTO `` (`Research_ID`,`Research_Field`) VALUES (12,'Aging');
INSERT INTO `` (`Research_ID`,`Research_Field`) VALUES (13,'Behavioral Disorders');
INSERT INTO `` (`Research_ID`,`Research_Field`) VALUES (14,'Developmental Biology');
INSERT INTO `` (`Research_ID`,`Research_Field`) VALUES (15,'Diabetes');
INSERT INTO `` (`Research_ID`,`Research_Field`) VALUES (16,'Obesity');
INSERT INTO `` (`Research_ID`,`Research_Field`) VALUES (17,'Immune Disorders');
INSERT INTO `` (`Research_ID`,`Research_Field`) VALUES (18,'Infectious Disease');
INSERT INTO `` (`Research_ID`,`Research_Field`) VALUES (19,'Neuromuscular Disease');
INSERT INTO `` (`Research_ID`,`Research_Field`) VALUES (20,'Neurodegenerative Disease');
INSERT INTO `` (`Research_ID`,`Research_Field`) VALUES (21,'Reproductive Disorders');
INSERT INTO `` (`Research_ID`,`Research_Field`) VALUES (22,'Skin Disease');
INSERT INTO `` (`Research_ID`,`Research_Field`) VALUES (23,'Complex Traits');
INSERT INTO `` (`Research_ID`,`Research_Field`) VALUES (24,'Resource Development');
INSERT INTO `` (`Research_ID`,`Research_Field`) VALUES (25,'Behavioral Disorders');
