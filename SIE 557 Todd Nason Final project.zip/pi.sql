/*
-- Query: SELECT * FROM 557_final_project.pi
LIMIT 0, 1000

-- Date: 2022-05-06 09:14
*/
INSERT INTO `` (`PI_ID`,`PI_FName`,`PI_LName`,`photo`) VALUES (1,'Mark','Adams','adams.png');
INSERT INTO `` (`PI_ID`,`PI_FName`,`PI_LName`,`photo`) VALUES (2,'Olga','Anczucow-Camarda','ancz.png');
INSERT INTO `` (`PI_ID`,`PI_FName`,`PI_LName`,`photo`) VALUES (3,'Chris','Baker','baker.png');
INSERT INTO `` (`PI_ID`,`PI_FName`,`PI_LName`,`photo`) VALUES (4,'Christine','Beck','beck.png');
INSERT INTO `` (`PI_ID`,`PI_FName`,`PI_LName`,`photo`) VALUES (5,'Judith','Blake','blake.png');
INSERT INTO `` (`PI_ID`,`PI_FName`,`PI_LName`,`photo`) VALUES (6,'Erik','Bloss','bloss.png');
INSERT INTO `` (`PI_ID`,`PI_FName`,`PI_LName`,`photo`) VALUES (7,'Ewelina','Bolcun-Filas','bolcun.png');
INSERT INTO `` (`PI_ID`,`PI_FName`,`PI_LName`,`photo`) VALUES (8,'Robert','Braun','braun.png');
INSERT INTO `` (`PI_ID`,`PI_FName`,`PI_LName`,`photo`) VALUES (9,'Carol','Bult','bult.png');
INSERT INTO `` (`PI_ID`,`PI_FName`,`PI_LName`,`photo`) VALUES (10,'Robert','Burgess','burgess.png');
INSERT INTO `` (`PI_ID`,`PI_FName`,`PI_LName`,`photo`) VALUES (11,'Gregory','Carter','carter.png');
INSERT INTO `` (`PI_ID`,`PI_FName`,`PI_LName`,`photo`) VALUES (12,'Elissa','Chesler','chesler.png');
INSERT INTO `` (`PI_ID`,`PI_FName`,`PI_LName`,`photo`) VALUES (13,'Jeffrey','Chuang','chuang.png');
INSERT INTO `` (`PI_ID`,`PI_FName`,`PI_LName`,`photo`) VALUES (14,'Gary','Churchill','churchill.png');
INSERT INTO `` (`PI_ID`,`PI_FName`,`PI_LName`,`photo`) VALUES (15,'Greg','Cox','cox.png');
INSERT INTO `` (`PI_ID`,`PI_FName`,`PI_LName`,`photo`) VALUES (16,'Beth','Dumont','dumont.png');
INSERT INTO `` (`PI_ID`,`PI_FName`,`PI_LName`,`photo`) VALUES (17,'Mary Ann','Handel','handel.png');
INSERT INTO `` (`PI_ID`,`PI_FName`,`PI_LName`,`photo`) VALUES (18,'David','Harrison','harrison.png');
INSERT INTO `` (`PI_ID`,`PI_FName`,`PI_LName`,`photo`) VALUES (19,'J.','Hinson','hinson.png');
INSERT INTO `` (`PI_ID`,`PI_FName`,`PI_LName`,`photo`) VALUES (20,'Gareth','Howell','howell.png');
INSERT INTO `` (`PI_ID`,`PI_FName`,`PI_LName`,`photo`) VALUES (21,'Catherine','Kaczorowski','kacz.png');
INSERT INTO `` (`PI_ID`,`PI_FName`,`PI_LName`,`photo`) VALUES (22,'Ron','Korstanje','korstanje.png');
INSERT INTO `` (`PI_ID`,`PI_FName`,`PI_LName`,`photo`) VALUES (23,'Vivek','Kumar','kumar.png');
INSERT INTO `` (`PI_ID`,`PI_FName`,`PI_LName`,`photo`) VALUES (24,'Ching','Lau','lau.png');
INSERT INTO `` (`PI_ID`,`PI_FName`,`PI_LName`,`photo`) VALUES (25,'Se-Jin','Lee','lee.png');
INSERT INTO `` (`PI_ID`,`PI_FName`,`PI_LName`,`photo`) VALUES (26,'Sheng','Li','li.png');
INSERT INTO `` (`PI_ID`,`PI_FName`,`PI_LName`,`photo`) VALUES (27,'Steven','Munger','munger.png');
INSERT INTO `` (`PI_ID`,`PI_FName`,`PI_LName`,`photo`) VALUES (28,'Vidhya','Munnamalai','munnamalai.png');
INSERT INTO `` (`PI_ID`,`PI_FName`,`PI_LName`,`photo`) VALUES (29,'Steve','Murray','murray.png');
INSERT INTO `` (`PI_ID`,`PI_FName`,`PI_LName`,`photo`) VALUES (30,'Patsy','Nishina','nishina.png');
INSERT INTO `` (`PI_ID`,`PI_FName`,`PI_LName`,`photo`) VALUES (31,'Kristen','O\'Connell','oconnell.png');
INSERT INTO `` (`PI_ID`,`PI_FName`,`PI_LName`,`photo`) VALUES (32,'Julia','Oh','oh.png');
INSERT INTO `` (`PI_ID`,`PI_FName`,`PI_LName`,`photo`) VALUES (33,'Karolina','Palucka','palucka.png');
INSERT INTO `` (`PI_ID`,`PI_FName`,`PI_LName`,`photo`) VALUES (34,'Jurgen','Naggert','naggert.png');
INSERT INTO `` (`PI_ID`,`PI_FName`,`PI_LName`,`photo`) VALUES (35,'Martin','Pera','pera.png');
INSERT INTO `` (`PI_ID`,`PI_FName`,`PI_LName`,`photo`) VALUES (36,'Luanne','Peters','peters.png');
INSERT INTO `` (`PI_ID`,`PI_FName`,`PI_LName`,`photo`) VALUES (37,'Laura','Reinholdt','reinholdt.png');
INSERT INTO `` (`PI_ID`,`PI_FName`,`PI_LName`,`photo`) VALUES (38,'Guangwen','Ren','ren.png');
INSERT INTO `` (`PI_ID`,`PI_FName`,`PI_LName`,`photo`) VALUES (39,'Martin','Ringwald','ringwald.png');
INSERT INTO `` (`PI_ID`,`PI_FName`,`PI_LName`,`photo`) VALUES (40,'Peter','Robinson','robinson.png');
INSERT INTO `` (`PI_ID`,`PI_FName`,`PI_LName`,`photo`) VALUES (41,'Derry','Roopenian','roopenian.png');
INSERT INTO `` (`PI_ID`,`PI_FName`,`PI_LName`,`photo`) VALUES (42,'Nadia','Rosenthal','rosenthal.png');
INSERT INTO `` (`PI_ID`,`PI_FName`,`PI_LName`,`photo`) VALUES (43,'David','Serreze','serreze.png');
INSERT INTO `` (`PI_ID`,`PI_FName`,`PI_LName`,`photo`) VALUES (44,'Lenny','Shultz','shultz.png');
INSERT INTO `` (`PI_ID`,`PI_FName`,`PI_LName`,`photo`) VALUES (45,'Shuzao','Li','li2.png');
INSERT INTO `` (`PI_ID`,`PI_FName`,`PI_LName`,`photo`) VALUES (46,'Michael','Stitzel','stitzel.png');
INSERT INTO `` (`PI_ID`,`PI_FName`,`PI_LName`,`photo`) VALUES (47,'Basile','Tarchini','tarchini.png');
INSERT INTO `` (`PI_ID`,`PI_FName`,`PI_LName`,`photo`) VALUES (48,'Ryan','Tewhey','tewhey.png');
INSERT INTO `` (`PI_ID`,`PI_FName`,`PI_LName`,`photo`) VALUES (49,'Jennifer','Trowbridge','trowbridge.png');
INSERT INTO `` (`PI_ID`,`PI_FName`,`PI_LName`,`photo`) VALUES (50,'Duygu','Ucar','ucar.png');
INSERT INTO `` (`PI_ID`,`PI_FName`,`PI_LName`,`photo`) VALUES (51,'Derya','Unutmaz','unutmaz.png');
INSERT INTO `` (`PI_ID`,`PI_FName`,`PI_LName`,`photo`) VALUES (52,'Roel','Verhaak','verhaak.png');
INSERT INTO `` (`PI_ID`,`PI_FName`,`PI_LName`,`photo`) VALUES (53,'Chia-Lin','Wei','wei.png');
INSERT INTO `` (`PI_ID`,`PI_FName`,`PI_LName`,`photo`) VALUES (54,'George','Weinstock','weinstock.png');
