/*
-- Query: SELECT * FROM 557_final_project.campus
LIMIT 0, 1000

-- Date: 2022-05-06 09:13
*/
INSERT INTO `` (`Campus_ID`,`Campus_City`,`Campus_State`) VALUES (1,'Bar Harbor','ME');
INSERT INTO `` (`Campus_ID`,`Campus_City`,`Campus_State`) VALUES (2,'Farmington','CT');
