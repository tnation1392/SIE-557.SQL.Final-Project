DB_SERVER = "localhost"
DB_USER = "pythonuser"
DB_PASS = ""
DB = "557_final_project"
DB_PORT = 3307
PHOTO_DIRECTORY = "images/"